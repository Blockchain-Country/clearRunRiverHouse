export const PREMIUM_AMENITIES = [
    {
        title: 'Outdoor Hot Tub',
        text: 'Relax in the hot tub surrounded by trees and fresh mountain air.',
        imageSrc: '../../assets/images/hotTub/hot_tub_1.JPG',
    },
    {
        title: 'Private Sauna',
        text: 'Recharge in the sauna after a day of hiking or skiing.',
        imageSrc: '/images/amenities/sauna/sauna_1.JPG',
    },
    {
        title: 'Billiards Room',
        text: 'Billiards, board games and a large TV for movie nights.',
        imageSrc: '/images/amenities/billiardRoom/billiard_1.JPG',
    },
    {
        title: 'Creek & Forest',
        text: 'Private access to Clear Run creek and wooded backyard Trails.',
        imageSrc: '/images/amenities/creek/creek_1.JPG',
    },
]

import Card from '../Cards/Card/Card'
import { PREMIUM_AMENITIES } from './PremiumAmentiesObj'

const PremiumAmenties = () => {
    return (
        <div>
            {PREMIUM_AMENITIES.map((obj) => (
                <Card
                    title={obj.title}
                    text={obj.text}
                    imageSrc={obj.imageSrc}
                    key={obj.title}
                ></Card>
            ))}
        </div>
    )
}

export default PremiumAmenties
